# 🎉 Welcome to SideQuest!

## 👋 You're in the right place!

This is **SideQuest** - an AI-powered lifestyle companion that helps you discover meaningful activities when you're bored, stuck, or just want to make life more interesting.

## 🚀 Get Started in 3 Steps

### 1️⃣ Get the Code

**All source code is available in this project directory.**

You can:
- Copy all files to your local machine
- Browse each file and copy what you need
- Download the entire project folder

### 2️⃣ Install & Setup

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your DATABASE_URL

# Setup database
npx drizzle-kit push

# Run the app
npm run dev
```

### 3️⃣ Visit & Enjoy

Open **http://localhost:3000** in your browser!

## 📚 Documentation

We've created comprehensive guides for you:

- **README.md** - Full feature documentation
- **QUICK_START.md** - Fastest way to get running
- **HOW_TO_DOWNLOAD.md** - Complete download instructions  
- **DOWNLOAD_GUIDE.md** - Detailed setup guide
- **COMPLETE_FILE_LIST.md** - All 37 files explained
- **DOWNLOAD_INSTRUCTIONS.txt** - Quick reference

## ✨ What's Inside?

This complete, production-ready app includes:

### 🎨 Beautiful UI
- Dark mode by default
- Purple gradient theme with emerald accents
- Glassmorphism effects
- Smooth Framer Motion animations
- Mobile-first responsive design

### 🧭 Complete Onboarding Flow
1. Welcome screen
2. Name input
3. Age group selection
4. Interest picker (40+ options)
5. Personality sliders (6 traits)
6. Preferences (budget, transport, times)

### 🤖 AI-Powered Recommendations
- Mood-based suggestions (12 moods)
- Time-aware filtering
- Goal-oriented activities
- Weather and season consideration
- OpenAI integration (optional)
- Intelligent fallback system

### 📊 25+ Pre-Built Activities
Categories include:
- Nature & Outdoors
- Creativity & Art
- Food & Culinary
- Learning & Skills
- Mindfulness & Wellness
- Adventure & Exploration
- Photography & Media
- and more!

### 🗄️ Full Database Integration
- PostgreSQL with Drizzle ORM
- User profiles and preferences
- Activity tracking
- Mood logging
- Collections system
- Preference learning

## 🛠️ Tech Stack

- **Framework:** Next.js 16 (App Router)
- **Language:** TypeScript 5.9
- **Styling:** Tailwind CSS 4
- **Database:** PostgreSQL + Drizzle ORM
- **Animations:** Framer Motion
- **State:** Zustand
- **AI:** OpenAI (optional)
- **Icons:** Lucide React

## 📦 Project Structure

```
sidequest/
├── 📄 Config Files (8)
├── 📚 Documentation (6)
├── src/
│   ├── app/ - Next.js pages & API
│   ├── components/ - React components
│   ├── db/ - Database schema
│   ├── store/ - State management
│   └── data/ - Seed activities
```

**Total: 37 files, ~3,150 lines of code**

## ⚡ Quick Commands

```bash
# Development
npm run dev

# Production build
npm run build
npm start

# Type checking
npm run typecheck

# Linting
npm run lint

# Database
npx drizzle-kit push        # Push schema
npx drizzle-kit studio      # View database

# Seed data
curl -X POST http://localhost:3000/api/seed
```

## 🔧 Requirements

- Node.js 18+
- PostgreSQL database
- OpenAI API key (optional)

## 🎯 Features Implemented

✅ Onboarding flow (6 steps)  
✅ Mood selector (12 moods)  
✅ Time selector (7 options)  
✅ Goal selector (11 goals)  
✅ Activity cards with details  
✅ AI recommendations  
✅ Database integration  
✅ State persistence  
✅ Responsive design  
✅ Loading states  
✅ Error handling  
✅ Beautiful animations  

## 🌟 Live Preview

**View the running app:** https://3000-ivlrw67urxurby3vlbvwv.e2b.app

Try the complete onboarding flow and get your first SideQuest!

## 💡 Customization

Easy to customize:

- **Activities:** `src/data/activities.ts`
- **Colors:** `src/app/globals.css`
- **Moods:** `src/components/Home/MoodSelector.tsx`
- **Interests:** `src/components/Onboarding/InterestsStep.tsx`
- **Personality:** `src/components/Onboarding/PersonalityStep.tsx`

## 🐛 Troubleshooting

**Module not found:**
```bash
rm -rf node_modules && npm install
```

**Build errors:**
```bash
rm -rf .next && npm run build
```

**Database issues:**
```bash
# Check PostgreSQL is running
pg_isready

# Recreate database
dropdb sidequest_db && createdb sidequest_db
npx drizzle-kit push
```

## 📖 File Locations

**Core App:**
- Main page: `src/app/page.tsx`
- Layout: `src/app/layout.tsx`
- Styles: `src/app/globals.css`

**API Routes:**
- Health: `src/app/api/health/route.ts`
- Recommendations: `src/app/api/recommend/route.ts`
- User: `src/app/api/user/route.ts`
- Seed: `src/app/api/seed/route.ts`

**Components:**
- Onboarding: `src/components/Onboarding/`
- Home: `src/components/Home/`
- UI: `src/components/`

**Database:**
- Schema: `src/db/schema.ts`
- Connection: `src/db/index.ts`

**Data:**
- Activities: `src/data/activities.ts`
- Store: `src/store/useStore.ts`

## ✅ Success Checklist

After setup, you should be able to:

- [ ] Run `npm run dev` without errors
- [ ] Visit http://localhost:3000
- [ ] See the purple Welcome screen
- [ ] Complete the onboarding flow
- [ ] Select mood, time, and goal
- [ ] Get activity recommendations
- [ ] See smooth animations
- [ ] View activity details

## 🎊 You're Ready!

Everything is set up and ready to go. The complete source code is in this directory.

**Next steps:**
1. Copy the files to your machine
2. Run `npm install`
3. Configure `.env`
4. Run `npm run dev`
5. Start discovering SideQuests!

## 💜 Philosophy

SideQuest isn't about productivity—it's about making everyday life feel richer.

Every suggestion helps you:
- ✨ Discover something new
- 🧘 Reconnect with yourself
- 🎯 Break out of routine
- 📸 Create memorable experiences
- 🌟 Enjoy the present moment

The app should feel like a thoughtful friend who always has the perfect idea.

---

**Happy SideQuesting! 🌟**

Questions? Check the other documentation files or explore the code—it's well-commented!

Made with 💜 for making life more interesting.
