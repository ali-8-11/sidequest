# 📥 SideQuest - Complete Download & Setup Guide

## Quick Start

### Option 1: Clone/Download the Repository

If you have access to this repository, simply clone it:

```bash
git clone <repository-url> sidequest
cd sidequest
npm install
cp .env.example .env
# Edit .env with your DATABASE_URL and OPENAI_API_KEY
npx drizzle-kit push
npm run dev
```

### Option 2: Manual Setup (Step-by-Step)

Follow these instructions to recreate the project from scratch:

## 1️⃣ Create Project Structure

```bash
mkdir sidequest
cd sidequest
mkdir -p src/{app/{api/{health,recommend,user,seed},},components/{Onboarding,Home},db,store,data}
```

## 2️⃣ Create Configuration Files

### `package.json`
```json
{
  "name": "sidequest",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "eslint .",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "dotenv": "17.3.1",
    "drizzle-orm": "0.45.2",
    "next": "16.2.6",
    "pg": "8.20.0",
    "react": "19.2.6",
    "react-dom": "19.2.6",
    "framer-motion": "^11.15.0",
    "openai": "^4.77.0",
    "date-fns": "^4.1.0",
    "lucide-react": "^0.469.0",
    "zustand": "^5.0.2"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "4.1.17",
    "@types/node": "22.19.15",
    "@types/pg": "8.18.0",
    "@types/react": "19.2.14",
    "@types/react-dom": "19.2.3",
    "drizzle-kit": "0.31.10",
    "eslint": "9.39.4",
    "eslint-config-next": "16.2.6",
    "postcss": "8.5.8",
    "tailwindcss": "4.1.17",
    "typescript": "5.9.3"
  }
}
```

### `tsconfig.json`
```json
{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./src/*"] }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

### `next.config.ts`
```typescript
import type { NextConfig } from "next";

const nextConfig: NextConfig = {};

export default nextConfig;
```

### `postcss.config.mjs`
```javascript
export default {
  plugins: {
    '@tailwindcss/postcss': {},
  },
};
```

### `drizzle.config.json`
```json
{
  "out": "./drizzle",
  "schema": "./src/db/schema.ts",
  "dialect": "postgresql",
  "dbCredentials": {
    "url": "postgresql://postgres:postgres@127.0.0.1:5432/app_db"
  }
}
```

### `.env`
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/sidequest_db
OPENAI_API_KEY=your_openai_api_key_here
```

## 3️⃣ Install Dependencies

```bash
npm install
```

## 4️⃣ Get All Source Files

All the source code files are available in this repository. The main files you need are:

### Core Application Files
- `src/app/layout.tsx` - Root layout with metadata
- `src/app/page.tsx` - Main application page with onboarding and home
- `src/app/globals.css` - Global styles and animations

### Database
- `src/db/index.ts` - Database connection
- `src/db/schema.ts` - Drizzle ORM schema

### API Routes
- `src/app/api/health/route.ts` - Health check
- `src/app/api/recommend/route.ts` - AI recommendation engine
- `src/app/api/user/route.ts` - User management
- `src/app/api/seed/route.ts` - Database seeding

### Components - Onboarding
- `src/components/Onboarding/Welcome.tsx`
- `src/components/Onboarding/NameStep.tsx`
- `src/components/Onboarding/AgeStep.tsx`
- `src/components/Onboarding/InterestsStep.tsx`
- `src/components/Onboarding/PersonalityStep.tsx`
- `src/components/Onboarding/PreferencesStep.tsx`

### Components - Home
- `src/components/Home/MoodSelector.tsx`
- `src/components/Home/TimeSelector.tsx`
- `src/components/Home/GoalSelector.tsx`
- `src/components/Home/ActivityCard.tsx`

### Components - UI
- `src/components/LoadingSpinner.tsx`
- `src/components/Header.tsx`
- `src/components/Navigation.tsx`

### Data & State
- `src/data/activities.ts` - Seed activity data (25 activities)
- `src/store/useStore.ts` - Zustand state management

## 5️⃣ Setup Database

```bash
# Make sure PostgreSQL is running
# Create database
createdb sidequest_db

# Push schema
npx drizzle-kit push
```

## 6️⃣ Run the Application

```bash
# Development
npm run dev

# Production
npm run build
npm start
```

Visit `http://localhost:3000`

## 7️⃣ Seed Initial Data (Optional)

Once the app is running, seed the database:

```bash
curl -X POST http://localhost:3000/api/seed
```

## 📁 Complete File Structure

```
sidequest/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── health/
│   │   │   │   └── route.ts
│   │   │   ├── recommend/
│   │   │   │   └── route.ts
│   │   │   ├── user/
│   │   │   │   └── route.ts
│   │   │   └── seed/
│   │   │       └── route.ts
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css
│   ├── components/
│   │   ├── Onboarding/
│   │   │   ├── Welcome.tsx
│   │   │   ├── NameStep.tsx
│   │   │   ├── AgeStep.tsx
│   │   │   ├── InterestsStep.tsx
│   │   │   ├── PersonalityStep.tsx
│   │   │   └── PreferencesStep.tsx
│   │   ├── Home/
│   │   │   ├── MoodSelector.tsx
│   │   │   ├── TimeSelector.tsx
│   │   │   ├── GoalSelector.tsx
│   │   │   └── ActivityCard.tsx
│   │   ├── LoadingSpinner.tsx
│   │   ├── Header.tsx
│   │   └── Navigation.tsx
│   ├── db/
│   │   ├── index.ts
│   │   └── schema.ts
│   ├── store/
│   │   └── useStore.ts
│   └── data/
│       └── activities.ts
├── package.json
├── tsconfig.json
├── next.config.ts
├── postcss.config.mjs
├── drizzle.config.json
├── .env
├── .env.example
├── .gitignore
├── README.md
└── INSTALL.sh

```

## 🎯 Key Features Implemented

✅ Beautiful dark mode UI with purple/emerald gradients  
✅ Smooth animations with Framer Motion  
✅ Complete onboarding flow (6 steps)  
✅ AI-powered activity recommendations  
✅ 25 pre-seeded activities across multiple categories  
✅ PostgreSQL database with Drizzle ORM  
✅ Mobile-first responsive design  
✅ Mood, time, and goal-based filtering  
✅ User preference learning  
✅ State persistence with Zustand  

## 🔧 Environment Variables

Required:
- `DATABASE_URL` - PostgreSQL connection string

Optional:
- `OPENAI_API_KEY` - For AI-generated activity explanations (fallback provided)

## 📝 Notes

- OpenAI API key is optional - the app will use intelligent fallback explanations
- The app uses localStorage to persist user data client-side
- Database stores user profiles, activities, and preferences
- All activities are stored in `src/data/activities.ts` and can be customized

## 🚀 Deployment

For production deployment:

1. Set up PostgreSQL database
2. Set environment variables
3. Run `npm run build`
4. Run `npm start`
5. Or deploy to Vercel/Netlify with PostgreSQL connection

## 💡 Tips

- Customize activities in `src/data/activities.ts`
- Adjust theme colors in `src/app/globals.css`
- Modify personality traits in `src/components/Onboarding/PersonalityStep.tsx`
- Add new moods in `src/components/Home/MoodSelector.tsx`

---

For any issues or questions, refer to the README.md file.

Happy SideQuesting! 🌟
