import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { seedActivities } from '@/data/activities';

const openai = process.env.OPENAI_API_KEY ? new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
}) : null;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { mood, timeAvailable, goal, user, weather = 'sunny', season = 'all' } = body;

    // Filter activities based on criteria
    let filteredActivities = seedActivities.filter(activity => {
      // Match mood
      const moodMatch = !mood || activity.moods.some(m => 
        m.toLowerCase().includes(mood.toLowerCase()) || 
        mood.toLowerCase().includes(m.toLowerCase())
      );

      // Match time available (convert time string to minutes)
      const timeInMinutes = convertTimeToMinutes(timeAvailable);
      const timeMatch = !timeAvailable || activity.duration <= timeInMinutes;

      // Match goal/category
      const goalMatch = !goal || 
        activity.category.toLowerCase().includes(goal.toLowerCase()) ||
        activity.tags.some(tag => tag.toLowerCase().includes(goal.toLowerCase()));

      // Match weather
      const weatherMatch = !weather || 
        activity.weather?.includes('all') || 
        activity.weather?.includes(weather.toLowerCase());

      // Match season
      const seasonMatch = !season || 
        activity.season?.includes('all') || 
        activity.season?.includes(season.toLowerCase());

      // Match user preferences if provided
      let userMatch = true;
      if (user?.interests) {
        const hasMatchingInterest = activity.tags.some(tag => 
          user.interests.some((interest: string) => 
            tag.toLowerCase().includes(interest.toLowerCase()) ||
            interest.toLowerCase().includes(tag.toLowerCase())
          )
        );
        userMatch = hasMatchingInterest || Math.random() > 0.5; // 50% chance for new experiences
      }

      return moodMatch && timeMatch && goalMatch && weatherMatch && seasonMatch && userMatch;
    });

    // If no matches, use all activities
    if (filteredActivities.length === 0) {
      filteredActivities = seedActivities;
    }

    // Pick 3 random activities
    const shuffled = filteredActivities.sort(() => 0.5 - Math.random());
    const recommendations = shuffled.slice(0, 3);

    // Generate AI explanation if OpenAI is available
    let aiExplanation = null;
    if (openai && recommendations.length > 0) {
      try {
        const completion = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: "You are a thoughtful lifestyle companion. Generate a brief, warm explanation (2-3 sentences) for why this activity is recommended. Be friendly and understanding."
            },
            {
              role: "user",
              content: `Activity: ${recommendations[0].title}\nMood: ${mood || 'not specified'}\nTime available: ${timeAvailable || 'not specified'}\nGoal: ${goal || 'not specified'}\n\nExplain why this is a good suggestion.`
            }
          ],
          max_tokens: 100,
          temperature: 0.7,
        });

        aiExplanation = completion.choices[0]?.message?.content?.trim();
      } catch (error) {
        console.error('OpenAI error:', error);
        // Fallback to default explanation
        aiExplanation = generateFallbackExplanation(mood, timeAvailable, goal, recommendations[0]);
      }
    } else {
      aiExplanation = generateFallbackExplanation(mood, timeAvailable, goal, recommendations[0]);
    }

    return NextResponse.json({
      recommendations,
      explanation: aiExplanation,
    });
  } catch (error) {
    console.error('Recommendation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate recommendations' },
      { status: 500 }
    );
  }
}

function convertTimeToMinutes(timeString: string | null): number {
  if (!timeString) return 999999;
  
  const timeMap: { [key: string]: number } = {
    '5 min': 5,
    '15 min': 15,
    '30 min': 30,
    '1 hour': 60,
    '2 hours': 120,
    'Half Day': 240,
    'Whole Day': 480,
  };
  
  return timeMap[timeString] || 999999;
}

function generateFallbackExplanation(
  mood: string | null, 
  time: string | null, 
  goal: string | null,
  activity: any
): string {
  const parts = [];
  
  if (mood) {
    parts.push(`You mentioned you're feeling ${mood.toLowerCase()}`);
  }
  
  if (time) {
    parts.push(`you have ${time.toLowerCase()}`);
  }
  
  if (goal) {
    parts.push(`and you want to ${goal.toLowerCase()}`);
  }

  const context = parts.length > 0 ? parts.join(', ') + '. ' : '';
  
  return `${context}${activity.title} is a ${activity.difficulty.toLowerCase()} ${activity.environment.toLowerCase()} activity that can help you recharge and find some joy in the moment.`;
}
