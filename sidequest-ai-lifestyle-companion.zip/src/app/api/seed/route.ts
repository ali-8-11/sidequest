import { NextResponse } from 'next/server';
import { db } from '@/db';
import { activities } from '@/db/schema';
import { seedActivities } from '@/data/activities';

export async function POST() {
  try {
    // Check if activities already exist
    const existing = await db.select().from(activities).limit(1);
    
    if (existing.length > 0) {
      return NextResponse.json({ message: 'Activities already seeded' });
    }

    // Insert seed activities
    await db.insert(activities).values(seedActivities);

    return NextResponse.json({ 
      message: 'Database seeded successfully',
      count: seedActivities.length 
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { error: 'Failed to seed database' },
      { status: 500 }
    );
  }
}
