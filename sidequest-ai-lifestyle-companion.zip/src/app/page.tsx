'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/store/useStore';
import Welcome from '@/components/Onboarding/Welcome';
import NameStep from '@/components/Onboarding/NameStep';
import AgeStep from '@/components/Onboarding/AgeStep';
import InterestsStep from '@/components/Onboarding/InterestsStep';
import PersonalityStep from '@/components/Onboarding/PersonalityStep';
import PreferencesStep from '@/components/Onboarding/PreferencesStep';
import MoodSelector from '@/components/Home/MoodSelector';
import TimeSelector from '@/components/Home/TimeSelector';
import GoalSelector from '@/components/Home/GoalSelector';
import ActivityCard from '@/components/Home/ActivityCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import Header from '@/components/Header';
import { Sparkles } from 'lucide-react';

type OnboardingStep = 'welcome' | 'name' | 'age' | 'interests' | 'personality' | 'preferences' | 'complete';

export default function Home() {
  const { user, onboardingComplete, setUser, completeOnboarding } = useStore();
  const [onboardingStep, setOnboardingStep] = useState<OnboardingStep>('welcome');
  const [onboardingData, setOnboardingData] = useState<any>({});
  
  const [mood, setMood] = useState<string | null>(null);
  const [timeAvailable, setTimeAvailable] = useState<string | null>(null);
  const [todayGoal, setTodayGoal] = useState<string | null>(null);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [currentRecommendation, setCurrentRecommendation] = useState(0);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showRecommendations, setShowRecommendations] = useState(false);

  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null; // Prevent hydration issues
  }

  const handleNameSubmit = (name: string) => {
    setOnboardingData((prev: any) => ({ ...prev, name }));
    setOnboardingStep('age');
  };

  const handleAgeSubmit = (ageGroup: string) => {
    setOnboardingData((prev: any) => ({ ...prev, ageGroup }));
    setOnboardingStep('interests');
  };

  const handleInterestsSubmit = (interests: string[]) => {
    setOnboardingData((prev: any) => ({ ...prev, interests }));
    setOnboardingStep('personality');
  };

  const handlePersonalitySubmit = (personality: any) => {
    setOnboardingData((prev: any) => ({ ...prev, personality }));
    setOnboardingStep('preferences');
  };

  const handlePreferencesSubmit = async (preferences: any) => {
    const finalData = { ...onboardingData, ...preferences };
    
    try {
      const response = await fetch('/api/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalData),
      });

      const data = await response.json();
      setUser({ ...finalData, id: data.user.id });
      completeOnboarding();
      setOnboardingStep('complete');
    } catch (error) {
      console.error('Failed to save user:', error);
      // Still complete onboarding for demo purposes
      setUser(finalData);
      completeOnboarding();
      setOnboardingStep('complete');
    }
  };

  const fetchRecommendations = async () => {
    if (!mood || !timeAvailable || !todayGoal) return;

    setLoading(true);
    try {
      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mood,
          timeAvailable,
          goal: todayGoal,
          user,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch recommendations');
      }

      const data = await response.json();
      
      if (data.recommendations && data.recommendations.length > 0) {
        setRecommendations(data.recommendations);
        setExplanation(data.explanation);
        setCurrentRecommendation(0);
        setShowRecommendations(true);
      } else {
        alert('No activities found. Try different preferences!');
      }
    } catch (error) {
      console.error('Failed to fetch recommendations:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    if (currentRecommendation < recommendations.length - 1) {
      setCurrentRecommendation(prev => prev + 1);
    } else {
      fetchRecommendations();
    }
  };

  const handleReset = () => {
    setShowRecommendations(false);
    setMood(null);
    setTimeAvailable(null);
    setTodayGoal(null);
  };

  // Onboarding flow
  if (!onboardingComplete) {
    return (
      <AnimatePresence mode="wait">
        {onboardingStep === 'welcome' && (
          <Welcome key="welcome" onStart={() => setOnboardingStep('name')} />
        )}
        {onboardingStep === 'name' && (
          <NameStep key="name" onNext={handleNameSubmit} />
        )}
        {onboardingStep === 'age' && (
          <AgeStep key="age" onNext={handleAgeSubmit} />
        )}
        {onboardingStep === 'interests' && (
          <InterestsStep key="interests" onNext={handleInterestsSubmit} />
        )}
        {onboardingStep === 'personality' && (
          <PersonalityStep key="personality" onNext={handlePersonalitySubmit} />
        )}
        {onboardingStep === 'preferences' && (
          <PreferencesStep key="preferences" onNext={handlePreferencesSubmit} />
        )}
      </AnimatePresence>
    );
  }

  // Main app
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <div className="min-h-screen gradient-purple">
      <div className="max-w-4xl mx-auto p-6 py-12">
        {!showRecommendations ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-12"
          >
            {/* App Header */}
            <Header onReset={() => {
              if (confirm('Reset the app and start over?')) {
                useStore.getState().reset();
                window.location.reload();
              }
            }} />

            {/* Greeting Header */}
            <div className="text-center space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200 }}
                className="inline-block"
              >
                <Sparkles className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
              </motion.div>
              <h1 className="text-4xl md:text-5xl font-bold">
                {getGreeting()}, {user?.name || 'Friend'}
              </h1>
              <p className="text-xl text-gray-300">
                Ready for your next SideQuest?
              </p>
            </div>

            {/* Selectors */}
            <div className="space-y-8 glass-dark rounded-3xl p-6 md:p-8">
              <MoodSelector onSelect={setMood} selected={mood} />
              <div className="border-t border-white/10"></div>
              <TimeSelector onSelect={setTimeAvailable} selected={timeAvailable} />
              <div className="border-t border-white/10"></div>
              <GoalSelector onSelect={setTodayGoal} selected={todayGoal} />
            </div>

            {/* Submit Button */}
            {loading ? (
              <LoadingSpinner />
            ) : (
              <motion.button
                whileHover={{ scale: mood && timeAvailable && todayGoal ? 1.02 : 1 }}
                whileTap={{ scale: mood && timeAvailable && todayGoal ? 0.98 : 1 }}
                onClick={fetchRecommendations}
                disabled={!mood || !timeAvailable || !todayGoal}
                className="w-full px-8 py-6 text-xl font-bold rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
              >
                Find My SideQuest
              </motion.button>
            )}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <button
              onClick={handleReset}
              className="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-2 mb-4"
            >
              ← Back
            </button>

            {recommendations[currentRecommendation] && (
              <ActivityCard
                activity={recommendations[currentRecommendation]}
                explanation={currentRecommendation === 0 ? explanation || undefined : undefined}
                onDone={() => alert('Great choice! Enjoy your SideQuest!')}
                onSave={() => alert('Saved for later!')}
                onRefresh={handleRefresh}
              />
            )}

            <p className="text-center text-gray-400 text-sm">
              Showing {currentRecommendation + 1} of {recommendations.length}
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
