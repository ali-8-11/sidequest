import { pgTable, uuid, text, timestamp, jsonb, integer, boolean, doublePrecision } from 'drizzle-orm/pg-core';

// Users table - stores user profile and preferences
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  ageGroup: text('age_group').notNull(),
  interests: jsonb('interests').notNull().$type<string[]>(),
  personality: jsonb('personality').notNull().$type<{
    adventure: number;
    introvert: number;
    creative: number;
    relaxed: number;
    spontaneous: number;
    indoor: number;
  }>(),
  budget: text('budget').notNull(),
  transportation: jsonb('transportation').notNull().$type<string[]>(),
  preferredTimes: jsonb('preferred_times').notNull().$type<string[]>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  lastActiveAt: timestamp('last_active_at').defaultNow().notNull(),
});

// Activities table - stores all available activities
export const activities = pgTable('activities', {
  id: uuid('id').defaultRandom().primaryKey(),
  emoji: text('emoji').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  category: text('category').notNull(),
  duration: integer('duration').notNull(), // in minutes
  budget: text('budget').notNull(),
  difficulty: text('difficulty').notNull(),
  environment: text('environment').notNull(), // indoor/outdoor/both
  tags: jsonb('tags').notNull().$type<string[]>(),
  moods: jsonb('moods').notNull().$type<string[]>(),
  season: jsonb('season').$type<string[]>(), // spring, summer, fall, winter, all
  weather: jsonb('weather').$type<string[]>(), // sunny, rainy, cloudy, all
  energyLevel: text('energy_level').notNull(), // low, medium, high
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// User activities - tracks completed and saved activities
export const userActivities = pgTable('user_activities', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  activityId: uuid('activity_id').notNull().references(() => activities.id, { onDelete: 'cascade' }),
  status: text('status').notNull(), // completed, saved, skipped
  moodBefore: integer('mood_before'),
  moodAfter: integer('mood_after'),
  reflection: text('reflection'),
  photo: text('photo'), // URL to photo
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Mood logs - tracks user moods over time
export const moodLogs = pgTable('mood_logs', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  mood: text('mood').notNull(),
  energy: integer('energy'), // 1-10
  timestamp: timestamp('timestamp').defaultNow().notNull(),
});

// Collections - user-created collections of activities
export const collections = pgTable('collections', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  activityIds: jsonb('activity_ids').notNull().$type<string[]>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Preferences learned over time
export const userPreferences = pgTable('user_preferences', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  key: text('key').notNull(),
  value: jsonb('value').notNull(),
  confidence: doublePrecision('confidence').notNull().default(0.5), // 0-1
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});
