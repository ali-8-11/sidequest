import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface UserProfile {
  id?: string;
  name: string;
  ageGroup: string;
  interests: string[];
  personality: {
    adventure: number;
    introvert: number;
    creative: number;
    relaxed: number;
    spontaneous: number;
    indoor: number;
  };
  budget: string;
  transportation: string[];
  preferredTimes: string[];
}

interface AppState {
  user: UserProfile | null;
  onboardingComplete: boolean;
  currentMood: string | null;
  currentEnergy: number | null;
  timeAvailable: string | null;
  todayGoal: string | null;
  setUser: (user: UserProfile) => void;
  completeOnboarding: () => void;
  setCurrentMood: (mood: string) => void;
  setCurrentEnergy: (energy: number) => void;
  setTimeAvailable: (time: string) => void;
  setTodayGoal: (goal: string) => void;
  reset: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      onboardingComplete: false,
      currentMood: null,
      currentEnergy: null,
      timeAvailable: null,
      todayGoal: null,
      setUser: (user) => set({ user }),
      completeOnboarding: () => set({ onboardingComplete: true }),
      setCurrentMood: (mood) => set({ currentMood: mood }),
      setCurrentEnergy: (energy) => set({ currentEnergy: energy }),
      setTimeAvailable: (time) => set({ timeAvailable: time }),
      setTodayGoal: (goal) => set({ todayGoal: goal }),
      reset: () => set({ 
        user: null, 
        onboardingComplete: false, 
        currentMood: null, 
        currentEnergy: null,
        timeAvailable: null,
        todayGoal: null 
      }),
    }),
    {
      name: 'sidequest-storage',
      storage: createJSONStorage(() => {
        if (typeof window !== 'undefined') {
          return localStorage;
        }
        return {
          getItem: () => null,
          setItem: () => {},
          removeItem: () => {},
        };
      }),
    }
  )
);
