'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

interface NameStepProps {
  onNext: (name: string) => void;
}

export default function NameStep({ onNext }: NameStepProps) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onNext(name.trim());
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          What should we call you?
        </h2>
        <p className="text-gray-400 text-center mb-12">
          Just your first name is perfect
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            autoFocus
            className="w-full px-6 py-4 text-xl bg-white/5 border border-white/10 rounded-3xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
          />

          <motion.button
            type="submit"
            disabled={!name.trim()}
            whileHover={{ scale: name.trim() ? 1.02 : 1 }}
            whileTap={{ scale: name.trim() ? 0.98 : 1 }}
            className="w-full px-8 py-4 text-lg font-semibold rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            Continue
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}
