'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

interface InterestsStepProps {
  onNext: (interests: string[]) => void;
}

const interestOptions = [
  'Reading', 'Gaming', 'Coding', 'Cooking', 'Photography',
  'Movies', 'Music', 'Coffee', 'Tea', 'Fitness',
  'Running', 'Yoga', 'Nature', 'Hiking', 'Drawing',
  'Painting', 'Writing', 'Anime', 'History', 'Science',
  'Technology', 'DIY', 'Astronomy', 'Psychology', 'Chess',
  'Board Games', 'Languages', 'Travel', 'Plants', 'Baking',
  'Fashion', 'Interior Design', 'Podcasts', 'Museums', 'Architecture',
  'Gardening', 'Volunteering', 'Learning', 'Business', 'Finance',
  'Pets', 'Meditation',
];

export default function InterestsStep({ onNext }: InterestsStepProps) {
  const [selected, setSelected] = useState<string[]>([]);

  const toggleInterest = (interest: string) => {
    setSelected(prev =>
      prev.includes(interest)
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  const handleSubmit = () => {
    if (selected.length > 0) {
      onNext(selected);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-3xl"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          What interests you?
        </h2>
        <p className="text-gray-400 text-center mb-8">
          Pick as many as you like
        </p>

        <div className="flex flex-wrap gap-3 mb-8 max-h-96 overflow-y-auto p-2">
          {interestOptions.map((interest, index) => (
            <motion.button
              key={interest}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.02 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toggleInterest(interest)}
              className={`px-6 py-3 rounded-full text-sm font-medium transition-all ${
                selected.includes(interest)
                  ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                  : 'glass hover:bg-white/10'
              }`}
            >
              {interest}
            </motion.button>
          ))}
        </div>

        <motion.button
          whileHover={{ scale: selected.length > 0 ? 1.02 : 1 }}
          whileTap={{ scale: selected.length > 0 ? 0.98 : 1 }}
          onClick={handleSubmit}
          disabled={selected.length === 0}
          className="w-full px-8 py-4 text-lg font-semibold rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          Continue ({selected.length} selected)
        </motion.button>
      </motion.div>
    </div>
  );
}
