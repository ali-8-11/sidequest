'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

interface AgeStepProps {
  onNext: (ageGroup: string) => void;
}

const ageGroups = [
  'Under 18',
  '18–24',
  '25–34',
  '35–44',
  '45+',
];

export default function AgeStep({ onNext }: AgeStepProps) {
  const [selected, setSelected] = useState<string | null>(null);

  const handleSelect = (ageGroup: string) => {
    setSelected(ageGroup);
    setTimeout(() => onNext(ageGroup), 300);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Age group
        </h2>
        <p className="text-gray-400 text-center mb-12">
          This helps us suggest age-appropriate activities
        </p>

        <div className="space-y-3">
          {ageGroups.map((age, index) => (
            <motion.button
              key={age}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSelect(age)}
              className={`w-full px-6 py-4 text-lg rounded-3xl transition-all ${
                selected === age
                  ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                  : 'glass hover:bg-white/10'
              }`}
            >
              {age}
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
