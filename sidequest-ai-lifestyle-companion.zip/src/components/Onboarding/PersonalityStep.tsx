'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

interface PersonalityStepProps {
  onNext: (personality: {
    adventure: number;
    introvert: number;
    creative: number;
    relaxed: number;
    spontaneous: number;
    indoor: number;
  }) => void;
}

type PersonalityValues = {
  adventure: number;
  introvert: number;
  creative: number;
  relaxed: number;
  spontaneous: number;
  indoor: number;
};

interface Slider {
  key: keyof PersonalityValues;
  left: string;
  right: string;
}

const sliders: Slider[] = [
  { key: 'adventure', left: 'Adventure', right: 'Comfort' },
  { key: 'introvert', left: 'Introvert', right: 'Extrovert' },
  { key: 'creative', left: 'Creative', right: 'Logical' },
  { key: 'relaxed', left: 'Relaxed', right: 'Productive' },
  { key: 'spontaneous', left: 'Spontaneous', right: 'Planner' },
  { key: 'indoor', left: 'Indoor', right: 'Outdoor' },
];

export default function PersonalityStep({ onNext }: PersonalityStepProps) {
  const [values, setValues] = useState<PersonalityValues>({
    adventure: 50,
    introvert: 50,
    creative: 50,
    relaxed: 50,
    spontaneous: 50,
    indoor: 50,
  });

  const handleChange = (key: string, value: number) => {
    setValues(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = () => {
    onNext(values);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Tell us about yourself
        </h2>
        <p className="text-gray-400 text-center mb-12">
          Move the sliders to where you feel you are
        </p>

        <div className="space-y-8 mb-8">
          {sliders.map((slider, index) => (
            <motion.div
              key={slider.key}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex justify-between text-sm mb-3">
                <span className="text-gray-400">{slider.left}</span>
                <span className="text-gray-400">{slider.right}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={values[slider.key as keyof typeof values]}
                onChange={(e) => handleChange(slider.key, parseInt(e.target.value))}
                className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer slider"
                style={{
                  background: `linear-gradient(to right, rgb(109, 40, 217) 0%, rgb(16, 185, 129) ${values[slider.key as keyof typeof values]}%, rgba(255,255,255,0.1) ${values[slider.key as keyof typeof values]}%, rgba(255,255,255,0.1) 100%)`,
                }}
              />
            </motion.div>
          ))}
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          className="w-full px-8 py-4 text-lg font-semibold rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white transition-all"
        >
          Continue
        </motion.button>
      </motion.div>
    </div>
  );
}
