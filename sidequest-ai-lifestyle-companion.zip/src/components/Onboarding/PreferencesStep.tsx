'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

interface PreferencesStepProps {
  onNext: (data: {
    budget: string;
    transportation: string[];
    preferredTimes: string[];
  }) => void;
}

const budgetOptions = ['Free', 'Under $10', 'Under $25', 'No preference'];
const transportOptions = ['Walk', 'Bike', 'Car', 'Transit', 'Stay Home'];
const timeOptions = ['Morning', 'Afternoon', 'Evening', 'Night'];

export default function PreferencesStep({ onNext }: PreferencesStepProps) {
  const [budget, setBudget] = useState<string | null>(null);
  const [transportation, setTransportation] = useState<string[]>([]);
  const [preferredTimes, setPreferredTimes] = useState<string[]>([]);

  const toggleItem = (
    item: string,
    list: string[],
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter(prev =>
      prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]
    );
  };

  const handleSubmit = () => {
    if (budget && transportation.length > 0 && preferredTimes.length > 0) {
      onNext({ budget, transportation, preferredTimes });
    }
  };

  const canSubmit = budget && transportation.length > 0 && preferredTimes.length > 0;

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Final touches
        </h2>
        <p className="text-gray-400 text-center mb-12">
          These help us personalize your experience
        </p>

        <div className="space-y-10">
          {/* Budget */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Budget</h3>
            <div className="grid grid-cols-2 gap-3">
              {budgetOptions.map((option) => (
                <motion.button
                  key={option}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setBudget(option)}
                  className={`px-6 py-3 rounded-2xl transition-all ${
                    budget === option
                      ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                      : 'glass hover:bg-white/10'
                  }`}
                >
                  {option}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Transportation */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Transportation</h3>
            <div className="flex flex-wrap gap-3">
              {transportOptions.map((option) => (
                <motion.button
                  key={option}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => toggleItem(option, transportation, setTransportation)}
                  className={`px-6 py-3 rounded-full transition-all ${
                    transportation.includes(option)
                      ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                      : 'glass hover:bg-white/10'
                  }`}
                >
                  {option}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Preferred Times */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Preferred Times</h3>
            <div className="grid grid-cols-2 gap-3">
              {timeOptions.map((option) => (
                <motion.button
                  key={option}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => toggleItem(option, preferredTimes, setPreferredTimes)}
                  className={`px-6 py-3 rounded-2xl transition-all ${
                    preferredTimes.includes(option)
                      ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                      : 'glass hover:bg-white/10'
                  }`}
                >
                  {option}
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: canSubmit ? 1.02 : 1 }}
          whileTap={{ scale: canSubmit ? 0.98 : 1 }}
          onClick={handleSubmit}
          disabled={!canSubmit}
          className="w-full mt-12 px-8 py-4 text-lg font-semibold rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          Complete Setup
        </motion.button>
      </motion.div>
    </div>
  );
}
