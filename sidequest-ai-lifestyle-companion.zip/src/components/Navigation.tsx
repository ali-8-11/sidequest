'use client';

import { motion } from 'framer-motion';
import { Home, Compass, BookMarked, User } from 'lucide-react';

interface NavigationProps {
  currentView?: 'home' | 'discover' | 'journal' | 'profile';
  onNavigate?: (view: 'home' | 'discover' | 'journal' | 'profile') => void;
}

export default function Navigation({ currentView = 'home', onNavigate }: NavigationProps) {
  const items = [
    { icon: Home, label: 'Home', view: 'home' as const },
    { icon: Compass, label: 'Discover', view: 'discover' as const },
    { icon: BookMarked, label: 'Journal', view: 'journal' as const },
    { icon: User, label: 'Profile', view: 'profile' as const },
  ];

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 pb-safe"
    >
      <div className="max-w-lg mx-auto px-6 pb-6">
        <div className="glass-dark rounded-full p-2 flex items-center justify-around shadow-2xl border border-white/20">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.view;
            
            return (
              <motion.button
                key={item.view}
                whileTap={{ scale: 0.9 }}
                onClick={() => onNavigate?.(item.view)}
                className={`relative p-3 rounded-full transition-colors ${
                  isActive ? 'text-emerald-400' : 'text-gray-400'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-emerald-500/20 rounded-full"
                  />
                )}
                <Icon className="w-6 h-6 relative z-10" />
              </motion.button>
            );
          })}
        </div>
      </div>
    </motion.nav>
  );
}
