'use client';

import { motion } from 'framer-motion';
import { Sparkles, Settings, RotateCcw } from 'lucide-react';

interface HeaderProps {
  onReset?: () => void;
}

export default function Header({ onReset }: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="flex items-center justify-between mb-8"
    >
      <div className="flex items-center gap-3">
        <Sparkles className="w-8 h-8 text-emerald-400" />
        <h1 className="text-2xl font-bold gradient-text">SideQuest</h1>
      </div>
      
      {onReset && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onReset}
          className="p-2 glass-dark rounded-full hover:bg-white/10 transition-colors"
          title="Reset onboarding"
        >
          <RotateCcw className="w-5 h-5" />
        </motion.button>
      )}
    </motion.header>
  );
}
