'use client';

import { motion } from 'framer-motion';
import { Clock, DollarSign, TrendingUp, MapPin } from 'lucide-react';

interface Activity {
  emoji: string;
  title: string;
  description: string;
  duration: number;
  budget: string;
  difficulty: string;
  environment: string;
  category: string;
}

interface ActivityCardProps {
  activity: Activity;
  explanation?: string;
  onSave?: () => void;
  onDone?: () => void;
  onRefresh?: () => void;
}

export default function ActivityCard({
  activity,
  explanation,
  onSave,
  onDone,
  onRefresh,
}: ActivityCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-dark rounded-3xl p-6 md:p-8 space-y-6"
    >
      {/* Header */}
      <div className="flex items-start gap-4">
        <div className="text-5xl">{activity.emoji}</div>
        <div className="flex-1">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">{activity.title}</h2>
          <div className="flex flex-wrap gap-3 text-sm text-gray-400">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{activity.duration} min</span>
            </div>
            <div className="flex items-center gap-1">
              <DollarSign className="w-4 h-4" />
              <span>{activity.budget}</span>
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>{activity.difficulty}</span>
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              <span>{activity.environment}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="text-gray-300 text-lg leading-relaxed whitespace-pre-line">
        {activity.description}
      </p>

      {/* AI Explanation */}
      {explanation && (
        <div className="p-4 rounded-2xl bg-purple-900/30 border border-purple-500/30">
          <p className="text-sm text-purple-200 italic">
            💭 {explanation}
          </p>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3">
        {onDone && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onDone}
            className="flex-1 px-6 py-3 rounded-full bg-gradient-to-r from-purple-600 to-emerald-500 text-white font-semibold"
          >
            I&apos;ll Do It!
          </motion.button>
        )}
        {onSave && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onSave}
            className="px-6 py-3 rounded-full glass hover:bg-white/10 font-semibold"
          >
            Save
          </motion.button>
        )}
        {onRefresh && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onRefresh}
            className="px-6 py-3 rounded-full glass hover:bg-white/10 font-semibold"
          >
            Another
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
