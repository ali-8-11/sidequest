'use client';

import { motion } from 'framer-motion';

interface MoodSelectorProps {
  onSelect: (mood: string) => void;
  selected: string | null;
}

const moods = [
  { emoji: '😊', label: 'Happy' },
  { emoji: '😔', label: 'Sad' },
  { emoji: '😴', label: 'Tired' },
  { emoji: '🤯', label: 'Overwhelmed' },
  { emoji: '🎨', label: 'Creative' },
  { emoji: '🔥', label: 'Motivated' },
  { emoji: '❤️', label: 'Romantic' },
  { emoji: '🥱', label: 'Bored' },
  { emoji: '😌', label: 'Peaceful' },
  { emoji: '🤔', label: 'Curious' },
  { emoji: '🌧', label: 'Cozy' },
  { emoji: '⚡', label: 'Energetic' },
];

export default function MoodSelector({ onSelect, selected }: MoodSelectorProps) {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">How are you feeling?</h3>
      <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
        {moods.map((mood, index) => (
          <motion.button
            key={mood.label}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(mood.label)}
            className={`p-4 rounded-3xl glass-dark flex flex-col items-center justify-center gap-2 transition-all ${
              selected === mood.label
                ? 'ring-2 ring-emerald-400 bg-emerald-500/20'
                : 'hover:bg-white/10'
            }`}
          >
            <span className="text-3xl">{mood.emoji}</span>
            <span className="text-xs font-medium">{mood.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
