'use client';

import { motion } from 'framer-motion';

interface GoalSelectorProps {
  onSelect: (goal: string) => void;
  selected: string | null;
}

const goals = [
  'Relax',
  'Learn',
  'Create',
  'Explore',
  'Move',
  'Reflect',
  'Meet People',
  'Eat',
  'Adventure',
  'Random',
  'Surprise Me',
];

export default function GoalSelector({ onSelect, selected }: GoalSelectorProps) {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Today&apos;s goal</h3>
      <div className="flex flex-wrap gap-3">
        {goals.map((goal, index) => (
          <motion.button
            key={goal}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(goal)}
            className={`px-6 py-3 rounded-full font-medium transition-all ${
              selected === goal
                ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                : 'glass-dark hover:bg-white/10'
            }`}
          >
            {goal}
          </motion.button>
        ))}
      </div>
    </div>
  );
}
