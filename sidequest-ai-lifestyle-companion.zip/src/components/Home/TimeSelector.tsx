'use client';

import { motion } from 'framer-motion';

interface TimeSelectorProps {
  onSelect: (time: string) => void;
  selected: string | null;
}

const timeOptions = [
  '5 min',
  '15 min',
  '30 min',
  '1 hour',
  '2 hours',
  'Half Day',
  'Whole Day',
];

export default function TimeSelector({ onSelect, selected }: TimeSelectorProps) {
  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Time available</h3>
      <div className="flex flex-wrap gap-3">
        {timeOptions.map((time, index) => (
          <motion.button
            key={time}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(time)}
            className={`px-6 py-3 rounded-full font-medium transition-all ${
              selected === time
                ? 'bg-gradient-to-r from-purple-600 to-emerald-500 text-white'
                : 'glass-dark hover:bg-white/10'
            }`}
          >
            {time}
          </motion.button>
        ))}
      </div>
    </div>
  );
}
