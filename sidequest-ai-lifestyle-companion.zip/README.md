# 🌟 SideQuest - Your AI-Powered Lifestyle Companion

SideQuest is a beautiful, mobile-first web application that helps you discover meaningful activities when you're bored, stuck, or simply want to make life more interesting.

## ✨ Features

### 🎯 Smart Onboarding
- Beautiful, gradual onboarding that learns about you
- No overwhelming questionnaires
- Personality sliders for nuanced understanding
- Interest selection from 40+ categories

### 🤖 AI-Powered Recommendations
- Personalized activity suggestions based on:
  - Current mood
  - Available time
  - Personal goals
  - User preferences
  - Weather and season
- Powered by OpenAI (optional)
- Intelligent fallback system

### 🎨 Beautiful Design
- Dark mode by default
- Purple gradient theme with emerald accents
- Glassmorphism UI elements
- Smooth animations with Framer Motion
- Mobile-first responsive design

### 📱 Activities Include
- **Nature**: Forest walks, sunrise missions, stargazing
- **Creativity**: Drawing, writing, photography challenges
- **Food**: Coffee roulette, mystery cooking, ice cream adventures
- **Learning**: Book browsing, skill snippets, time machine music
- **Mindfulness**: Breathing exercises, rain therapy, reflection
- **Adventure**: New routes, say yes day, exploration

### 🗄️ Database-Backed
- PostgreSQL with Drizzle ORM
- User profiles and preferences
- Activity tracking and journaling
- Mood logging
- Collections and saved quests

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database
- OpenAI API key (optional, for AI explanations)

### Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Set up environment variables in `.env`:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/sidequest
OPENAI_API_KEY=your_openai_api_key_here  # Optional
```

4. Push the database schema:
```bash
npx drizzle-kit push
```

5. Run the development server:
```bash
npm run dev
```

6. Open [http://localhost:3000](http://localhost:3000)

### Seeding Activities

To populate the database with initial activities:
```bash
curl -X POST http://localhost:3000/api/seed
```

## 🏗️ Tech Stack

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS 4
- **Animations**: Framer Motion
- **Database**: PostgreSQL + Drizzle ORM
- **AI**: OpenAI GPT-3.5 Turbo (optional)
- **State Management**: Zustand
- **Icons**: Lucide React

## 📁 Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── health/       # Health check endpoint
│   │   ├── recommend/    # AI recommendation engine
│   │   ├── user/         # User management
│   │   └── seed/         # Database seeding
│   ├── layout.tsx        # Root layout
│   ├── page.tsx          # Main application page
│   └── globals.css       # Global styles
├── components/
│   ├── Onboarding/       # Onboarding flow components
│   │   ├── Welcome.tsx
│   │   ├── NameStep.tsx
│   │   ├── AgeStep.tsx
│   │   ├── InterestsStep.tsx
│   │   ├── PersonalityStep.tsx
│   │   └── PreferencesStep.tsx
│   ├── Home/             # Main app components
│   │   ├── MoodSelector.tsx
│   │   ├── TimeSelector.tsx
│   │   ├── GoalSelector.tsx
│   │   └── ActivityCard.tsx
│   ├── LoadingSpinner.tsx
│   └── Navigation.tsx
├── data/
│   └── activities.ts     # Seed activity data
├── db/
│   ├── index.ts          # Database connection
│   └── schema.ts         # Drizzle schema definitions
└── store/
    └── useStore.ts       # Zustand state management
```

## 🎨 Design Philosophy

SideQuest is designed to help users:
- ✨ Discover something new
- 🧘 Reconnect with themselves
- 🎯 Break out of routine
- 📸 Create memorable experiences
- 🌟 Enjoy the present moment

The app should feel like a thoughtful friend who always has the perfect idea for what to do next.

## 🔮 Future Features

- AI-generated weekend itineraries
- Travel mode
- Couple mode & Family mode
- Pet-friendly SideQuests
- Offline mode
- Calendar integration
- Spotify integration for activity playlists
- Photo memories
- Local event recommendations
- "Spin the Wheel" for spontaneous ideas

## 📝 License

MIT License - feel free to use this project for your own purposes!

## 🙏 Acknowledgments

Inspired by:
- Spotify Discover Weekly
- Apple Health
- Pinterest
- Nintendo
- Calm

---

Made with 💜 and ✨ for making everyday life richer.
