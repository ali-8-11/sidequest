#!/bin/bash

# SideQuest - One Command Installer
# Run this script to create the complete SideQuest application

echo "🌟 SideQuest - One Command Installer"
echo "===================================="
echo ""

# Check if directory already exists
if [ -d "sidequest" ]; then
    echo "⚠️  Directory 'sidequest' already exists!"
    read -p "Delete and recreate? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
    rm -rf sidequest
fi

# Clone or download
echo "📦 Downloading SideQuest..."
echo ""
echo "You can get the complete source code by:"
echo "1. Cloning the repository (if available)"
echo "2. Downloading from the source"
echo "3. Copying all files from the current directory"
echo ""

# For now, let's copy from current directory
echo "Copying files..."
cp -r . sidequest/ 2>/dev/null || echo "Manual download required"

cd sidequest 2>/dev/null || exit 1

echo ""
echo "📋 Next steps:"
echo ""
echo "1. cd sidequest"
echo "2. npm install"
echo "3. Copy .env.example to .env and configure:"
echo "   - DATABASE_URL"
echo "   - OPENAI_API_KEY (optional)"
echo "4. npx drizzle-kit push"
echo "5. npm run dev"
echo ""
echo "Visit http://localhost:3000 to start!"
echo ""
echo "For detailed instructions, see DOWNLOAD_GUIDE.md"

