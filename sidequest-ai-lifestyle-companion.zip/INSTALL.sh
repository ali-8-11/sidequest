#!/bin/bash

# SideQuest Installation Script
# This script will guide you through setting up SideQuest locally

set -e

echo "🌟 SideQuest - AI-Powered Lifestyle Companion"
echo "=============================================="
echo ""

# Check for required tools
echo "🔍 Checking prerequisites..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    echo "   Visit: https://nodejs.org/"
    exit 1
fi

if ! command -v psql &> /dev/null; then
    echo "⚠️  PostgreSQL client not found. Make sure PostgreSQL is installed."
    echo "   Visit: https://www.postgresql.org/download/"
fi

echo "✅ Prerequisites check passed"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Setup environment
if [ ! -f .env ]; then
    echo ""
    echo "⚙️  Setting up environment variables..."
    cp .env.example .env
    echo "✅ Created .env file"
    echo ""
    echo "📝 Please edit .env and add your:"
    echo "   - DATABASE_URL (PostgreSQL connection string)"
    echo "   - OPENAI_API_KEY (optional, for AI recommendations)"
    echo ""
    read -p "Press Enter after you've updated .env file..."
fi

# Setup database
echo ""
echo "🗄️  Setting up database..."
read -p "Do you want to push the database schema now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npx drizzle-kit push
    echo "✅ Database schema created"
fi

# Seed database
echo ""
read -p "Do you want to seed the database with activities? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Starting dev server temporarily to seed..."
    npm run dev &
    DEV_PID=$!
    sleep 5
    curl -X POST http://localhost:3000/api/seed
    kill $DEV_PID
    echo "✅ Database seeded"
fi

echo ""
echo "🎉 Installation complete!"
echo ""
echo "To start the development server:"
echo "  npm run dev"
echo ""
echo "To build for production:"
echo "  npm run build"
echo "  npm start"
echo ""
echo "Visit http://localhost:3000 to start your SideQuest journey!"
