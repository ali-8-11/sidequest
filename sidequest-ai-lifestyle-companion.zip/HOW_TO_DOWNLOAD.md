# 📥 How to Download SideQuest - Complete Instructions

## 🎯 Three Ways to Get SideQuest

### Method 1: Direct File Access (Easiest) ⭐

If you're viewing this in a file browser or repository:

1. **Download the entire project folder**
   - Look for a "Download ZIP" button, or
   - Clone the repository if using Git

2. **Extract and install:**
```bash
cd sidequest
npm install
cp .env.example .env
# Edit .env with your database URL
npx drizzle-kit push
npm run dev
```

### Method 2: Copy Individual Files

If you need to recreate the project manually:

1. **Create project structure:**
```bash
mkdir -p sidequest/src/{app/{api/{health,recommend,user,seed},},components/{Onboarding,Home},db,store,data}
cd sidequest
```

2. **Install dependencies:**
```bash
npm init -y
npm install next@16.2.6 react@19.2.6 react-dom@19.2.6 \
  typescript@5.9.3 @types/react @types/node @types/react-dom \
  tailwindcss@4.1.17 @tailwindcss/postcss postcss \
  drizzle-orm@0.45.2 drizzle-kit@0.31.10 pg@8.20.0 @types/pg \
  framer-motion openai zustand lucide-react date-fns \
  eslint eslint-config-next
```

3. **Copy each file** from the source (see COMPLETE_FILE_LIST.md for all 37 files)

### Method 3: From Preview/Running App

If you're viewing the live preview:

**All source files are available in this project.**

You can view each file's content and copy it manually:

📂 **Key Files to Copy:**

**Root Level:**
- `package.json`
- `tsconfig.json`
- `next.config.ts`
- `postcss.config.mjs`
- `drizzle.config.json`
- `.env.example`

**Source Code:**
- `src/app/layout.tsx`
- `src/app/page.tsx`
- `src/app/globals.css`
- `src/app/api/*/route.ts` (4 files)
- `src/components/**/*.tsx` (13 files)
- `src/db/*.ts` (2 files)
- `src/store/useStore.ts`
- `src/data/activities.ts`

## 🚀 After Downloading

Regardless of which method you used:

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Configure Environment
```bash
cp .env.example .env
```

Edit `.env` and add:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/sidequest_db
OPENAI_API_KEY=sk-... # Optional
```

### Step 3: Setup Database
```bash
# Create database
createdb sidequest_db

# Push schema
npx drizzle-kit push
```

### Step 4: Run the App
```bash
# Development
npm run dev

# Or production
npm run build
npm start
```

### Step 5: Seed Data (Optional)
```bash
curl -X POST http://localhost:3000/api/seed
```

## 📋 File Checklist

After download, verify you have these files:

### Configuration (8 files)
- [ ] `package.json`
- [ ] `tsconfig.json`
- [ ] `next.config.ts`
- [ ] `postcss.config.mjs`
- [ ] `eslint.config.mjs`
- [ ] `drizzle.config.json`
- [ ] `.env.example`
- [ ] `.gitignore`

### App Core (3 files)
- [ ] `src/app/layout.tsx`
- [ ] `src/app/page.tsx`
- [ ] `src/app/globals.css`

### API Routes (4 files)
- [ ] `src/app/api/health/route.ts`
- [ ] `src/app/api/recommend/route.ts`
- [ ] `src/app/api/user/route.ts`
- [ ] `src/app/api/seed/route.ts`

### Components (13 files)
- [ ] `src/components/Onboarding/Welcome.tsx`
- [ ] `src/components/Onboarding/NameStep.tsx`
- [ ] `src/components/Onboarding/AgeStep.tsx`
- [ ] `src/components/Onboarding/InterestsStep.tsx`
- [ ] `src/components/Onboarding/PersonalityStep.tsx`
- [ ] `src/components/Onboarding/PreferencesStep.tsx`
- [ ] `src/components/Home/MoodSelector.tsx`
- [ ] `src/components/Home/TimeSelector.tsx`
- [ ] `src/components/Home/GoalSelector.tsx`
- [ ] `src/components/Home/ActivityCard.tsx`
- [ ] `src/components/LoadingSpinner.tsx`
- [ ] `src/components/Header.tsx`
- [ ] `src/components/Navigation.tsx`

### Database & Data (4 files)
- [ ] `src/db/index.ts`
- [ ] `src/db/schema.ts`
- [ ] `src/store/useStore.ts`
- [ ] `src/data/activities.ts`

**Total: 32 essential files** (+ 5 documentation files)

## 🔧 Troubleshooting

### "Module not found" errors
```bash
rm -rf node_modules package-lock.json
npm install
```

### Database connection issues
- Make sure PostgreSQL is running
- Check DATABASE_URL in .env
- Verify database exists: `psql -l`

### Build errors
```bash
rm -rf .next
npm run build
```

### TypeScript errors
```bash
npx tsc --noEmit
```

## 📦 What You Get

✨ A complete, production-ready app with:

- ✅ Beautiful dark UI (purple/emerald theme)
- ✅ 6-step onboarding flow
- ✅ AI-powered recommendations
- ✅ 25+ pre-built activities
- ✅ PostgreSQL database
- ✅ Mobile-first responsive
- ✅ Smooth animations
- ✅ TypeScript + Next.js 16
- ✅ Tailwind CSS 4

## 🎨 Customization

Once downloaded, customize:

- **Activities**: Edit `src/data/activities.ts`
- **Colors**: Modify `src/app/globals.css`
- **Moods**: Update `src/components/Home/MoodSelector.tsx`
- **Interests**: Edit `src/components/Onboarding/InterestsStep.tsx`

## 📚 Additional Resources

- `README.md` - Full feature documentation
- `QUICK_START.md` - Quick setup guide
- `DOWNLOAD_GUIDE.md` - Detailed download instructions
- `COMPLETE_FILE_LIST.md` - Every file in the project
- `INSTALL.sh` - Automated installation script

## ✅ Success Criteria

You'll know it's working when:

1. `npm install` completes without errors
2. `npm run dev` starts the server
3. You can visit `http://localhost:3000`
4. You see the purple Welcome screen with "SideQuest"
5. Onboarding flow works smoothly
6. Activity recommendations appear

## 🎉 You're Done!

Welcome to SideQuest! Start your journey:

```bash
npm run dev
```

Visit: **http://localhost:3000**

---

Need help? Check the other documentation files or the inline code comments.

**Made with 💜 for making life more interesting!**
