# 🚀 SideQuest - Quick Start Guide

## Download Complete Source Code

### Method 1: Direct Download (Recommended)

Download all files from this project directory. Here's what you need:

**Required Files & Folders:**
```
✅ src/ (entire folder)
✅ package.json
✅ tsconfig.json
✅ next.config.ts
✅ postcss.config.mjs
✅ drizzle.config.json
✅ .env.example
✅ README.md
```

### Method 2: Copy-Paste Setup

If downloading isn't available, you can recreate the project by copying each file:

1. **Create the project structure:**
```bash
mkdir sidequest && cd sidequest
npm init -y
```

2. **Install Next.js and dependencies:**
```bash
npm install next@16.2.6 react@19.2.6 react-dom@19.2.6 typescript@5.9.3 \
  @types/react @types/node tailwindcss@4.1.17 @tailwindcss/postcss \
  drizzle-orm@0.45.2 pg@8.20.0 @types/pg drizzle-kit@0.31.10 \
  framer-motion openai zustand lucide-react date-fns
```

3. **Copy the configuration files** listed in DOWNLOAD_GUIDE.md

4. **Copy all source code files** from the `src/` directory

## 📦 Installation Steps

Once you have all the files:

```bash
# 1. Install dependencies
npm install

# 2. Set up environment
cp .env.example .env
# Edit .env with your DATABASE_URL

# 3. Set up database (make sure PostgreSQL is running)
createdb sidequest_db
npx drizzle-kit push

# 4. Run development server
npm run dev

# 5. (Optional) Seed database with activities
curl -X POST http://localhost:3000/api/seed
```

Visit: **http://localhost:3000**

## 🎯 What You Get

✨ **Full-Featured Application:**
- Beautiful dark UI with purple/emerald theme
- Complete onboarding flow (6 steps)
- AI-powered activity recommendations
- 25+ pre-built activities
- Mood, time, and goal-based filtering
- PostgreSQL database integration
- Mobile-first responsive design
- Smooth animations throughout

## 📁 File Overview

Here's what each directory contains:

- **src/app/** - Next.js app router pages and API routes
- **src/components/** - React components (Onboarding, Home, UI)
- **src/db/** - Database schema and connection
- **src/store/** - State management (Zustand)
- **src/data/** - Seed data for activities

## 🔧 Configuration

### Required Environment Variables

```env
DATABASE_URL=postgresql://user:pass@localhost:5432/sidequest_db
```

### Optional Environment Variables

```env
OPENAI_API_KEY=sk-...  # For AI-generated explanations
```

> **Note:** OpenAI API key is optional. The app includes intelligent fallback explanations.

## 🐛 Troubleshooting

**Issue:** `Cannot find module '@/...'`  
**Fix:** Make sure tsconfig.json has the `"@/*": ["./src/*"]` path mapping

**Issue:** Database connection fails  
**Fix:** Verify PostgreSQL is running and DATABASE_URL is correct

**Issue:** Build errors  
**Fix:** Delete `.next` folder and `node_modules`, then run `npm install` again

## 🎨 Customization

Want to customize SideQuest?

- **Activities:** Edit `src/data/activities.ts`
- **Colors:** Modify `src/app/globals.css`
- **Moods:** Update `src/components/Home/MoodSelector.tsx`
- **Interests:** Edit `src/components/Onboarding/InterestsStep.tsx`

## 📚 Tech Stack

- **Framework:** Next.js 16 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS 4
- **Database:** PostgreSQL + Drizzle ORM
- **Animations:** Framer Motion
- **AI:** OpenAI (optional)
- **State:** Zustand
- **Icons:** Lucide React

## 🌐 Deployment

Deploy to production:

1. **Vercel** (Recommended for Next.js)
   - Connect your repository
   - Add environment variables
   - Deploy

2. **Any VPS**
   ```bash
   npm run build
   npm start
   ```

3. **Docker** (create Dockerfile)
   ```dockerfile
   FROM node:18
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   RUN npm run build
   CMD ["npm", "start"]
   ```

## 📞 Support

For issues:
1. Check DOWNLOAD_GUIDE.md for detailed setup
2. Review README.md for feature documentation
3. Check the GitHub issues (if applicable)

## ✨ Start Building

You're all set! Run `npm run dev` and visit http://localhost:3000

Welcome to SideQuest! 🌟

---

**Pro Tip:** Star ⭐ the repository if you find this useful!
